const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.Bullet,
		C3.Plugins.Keyboard,
		C3.Plugins.Text,
		C3.Plugins.Sprite.Cnds.OnCreated,
		C3.Plugins.Sprite.Acts.SetAnimFrame,
		C3.Plugins.System.Exps.random,
		C3.Plugins.Sprite.Acts.SetScale,
		C3.Plugins.System.Exps.choose,
		C3.Behaviors.Bullet.Acts.SetSpeed,
		C3.Plugins.Sprite.Cnds.IsOnScreen,
		C3.Plugins.Keyboard.Cnds.OnKey,
		C3.Plugins.Sprite.Cnds.CompareFrame,
		C3.Plugins.Sprite.Acts.Destroy,
		C3.Plugins.Sprite.Cnds.OnDestroyed,
		C3.Plugins.Sprite.Acts.AddInstanceVar,
		C3.Plugins.Text.Acts.SetText,
		C3.Plugins.System.Cnds.Every,
		C3.Plugins.System.Acts.CreateObject,
		C3.Plugins.Sprite.Cnds.CompareInstanceVar,
		C3.Plugins.Sprite.Acts.SubInstanceVar,
		C3.Plugins.Sprite.Cnds.CompareX,
		C3.Plugins.System.Acts.GoToLayout,
		C3.Plugins.Keyboard.Cnds.OnAnyKey,
		C3.Plugins.System.Acts.Wait
	];
};
self.C3_JsPropNameTable = [
	{Bullet: 0},
	{obj_letter: 0},
	{Keyboard: 0},
	{letterCounter: 0},
	{spawnTime: 0},
	{game_manager: 0},
	{txt_letter_counter: 0},
	{Text: 0},
	{obj_helper: 0}
];

self.InstanceType = {
	obj_letter: class extends self.ISpriteInstance {},
	Keyboard: class extends self.IInstance {},
	game_manager: class extends self.ISpriteInstance {},
	txt_letter_counter: class extends self.ITextInstance {},
	Text: class extends self.ITextInstance {},
	obj_helper: class extends self.ISpriteInstance {}
}